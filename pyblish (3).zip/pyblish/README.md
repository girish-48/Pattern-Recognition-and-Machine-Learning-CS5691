# publish

Use the default plotting style in the file publish.py for plots in python. You can change the size of the fonts on the title,axis,change the color schemes and plotting styles. Once the defaults are set all the plots produced will be consistent for a specific publication requirements.
